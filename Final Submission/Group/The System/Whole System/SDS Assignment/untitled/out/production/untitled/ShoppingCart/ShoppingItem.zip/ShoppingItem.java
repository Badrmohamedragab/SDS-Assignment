package ShoppingCart;
import Products.Product;

public class ShoppingItem {
    Product item ;
    int quantity ;

    public ShoppingItem(Product item, int quantity) {
        this.item = item;
        this.quantity = quantity;
    }

    public void print() {
        System.out.println(quantity + " of -> " +
                item.getInfo().getName() + "\nPrice of one unit\\Kilo -> " + item.getInfo().getPrice()) ;
    }

//    public int getId() {
//        return item.getInfo().getId() ;
//    }

    public void addQuantity(int quantity) {
        this.quantity += quantity ;
    }
//
//    public double totalPriceForItem(){
//        double productPrice = this.item.getInfo().getPrice(), discount = this.item.getInfo().getDiscountAmount();
//        return (this.quantity) * (productPrice - (productPrice * discount));
//    }
}
