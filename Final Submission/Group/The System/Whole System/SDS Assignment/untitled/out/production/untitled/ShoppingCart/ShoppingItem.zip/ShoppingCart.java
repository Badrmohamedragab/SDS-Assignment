package ShoppingCart;
import Database.Control;
import Products.ByUnits;
import Products.Product;
import Products.Status;
import Products.UnitType;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ShoppingCart {
    Map<Integer, ShoppingItem> shoppingCartList ;
    int id ;
    int userId ;
    double totalPrice ;
    int numberOfItems ;
    public ShoppingCart(int userId, int Id){
        shoppingCartList = new HashMap<>() ;
        id = Id ;
        this.userId = userId ;
        totalPrice = 0 ;
        numberOfItems = 0 ;
    }

    public int getId() {
        return id ;
    }

    public int getUserId() {
        return userId ;
    }

    public int getNumberOfItems() {
        return numberOfItems;
    }

    public double getTotalPrice() {
        return totalPrice;
    }

    public void print() {
        System.out.println("<-------------- Cart -------------->");
        System.out.println("Cart id -> " + id + "\nNumber of items in it -> " + numberOfItems);

        if (shoppingCartList.values().size() == 0){
            System.out.print("No items added yet");
        }
        else {
            int i =  1;
            for (ShoppingItem SI : shoppingCartList.values()) {
                System.out.println("---------- Product# " + i++ + " ----------");
                SI.print();
            }
        }
        System.out.println("\nTotal Price -> $" + totalPrice);
    }
    private void addProductToList(Product product, int quantity){
        ShoppingItem shoppingItem = new ShoppingItem(product, quantity) ;

        if (shoppingCartList.containsKey(product.getInfo().getId())){
            shoppingCartList.get(product.getInfo().getId()).addQuantity(quantity) ;
        }
        else{
            shoppingCartList.put(product.getInfo().getId(), shoppingItem) ;
        }
    }
    public void addProduct(Product product, int quantity) throws SQLException {
        if (this.shoppingCartList.size() == 0){
            shoppingCartList = new HashMap<>();
        }
        double pPrice = product.getInfo().getPrice() ;
        totalPrice += (quantity * (pPrice - (pPrice * product.getInfo().getDiscountAmount()))) ;

        UnitType unitType = product.getInfo().getUnitType() ;

        if (quantity > unitType.getMaxAmount()){
            System.out.print("Can't add product upon " + unitType.getMaxAmount());
            if (unitType instanceof ByUnits){
                System.out.println(" Units");
            }
            else{
                System.out.println(" Kilos");
            }
            return ;
        }
        if (product.getInfo().getStatus() == Status.OutOfStock){
            System.out.println("This Product is out of stock");
            return ;
        }
        if (quantity > product.getInfo().getQuantity()){
            System.out.println("You exceeded quantity limit\nQuantity of this product -> " + product.getInfo().getQuantity());
            return ;
        }

        addProductToList(product, quantity) ;
        numberOfItems += quantity ;

        Control control = new Control() ;
        control.UpdateProduct(product, this, quantity) ;
        System.out.println("You added " + quantity + " of " + product.getInfo().getName() + " successfully");
    }
//    public boolean hasProduct(Product product) {
//        for (ShoppingItem item : shoppingCartList.values()) {
//            if (item.getId() == product.getInfo().getId()){
//                return true ;
//            }
//        }
//        return false ;
//    }

    public List<ShoppingItem> getItems() {
        return new LinkedList<>(shoppingCartList.values());
    }
    public void reset() {
        shoppingCartList.clear();
        totalPrice = 0;
        numberOfItems = 0;
    }

    public boolean isEmpty() {
        return shoppingCartList.isEmpty() ;
    }
}
